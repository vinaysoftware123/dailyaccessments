package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestWebserviceCrudApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestWebserviceCrudApplication.class, args);
	}

}
